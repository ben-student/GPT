#ifndef DEFINE FUNCTIES
#define DEFINE FUNCTIES

void specialPrint(char* formatString,...);


void consoleInput(int buffer);

void readConfigFile(char* path);

void foperation(char* function, double* numbers, int length);

char** str_split(char* str, char* token);

int str_length(char* str);

#endif /*FUNCTIES.H*/