#ifndef DEFINE DATASTRUCT
#define DEFINE DATASTRUCT

typedef struct Node *PtrToNode;
typedef PtrToNode List;
typedef PtrToNode Position;

#endif /*DATASTRUCT.H*/