#ifndef DEFINE STRINGMANIPULATIES
#define DEFINE STRINGMANIPULATIES

int str_length(char* str);

char* str_cat(char* str_left, char* str_right);

char** str_split(char* str, char* token);

#endif /*STRINGMANIPULATIE.H*/