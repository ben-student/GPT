#include "functies.h"
#include <stdio.h>
#include <string.h>
// #<include "stringManipulaties.h"



int main( int argc, char** argv ) {
    // specialPrint("This is some kind of string : %s, this is an integer : %d ", "helloWorld", 69);


    // char text[256]; // make an array of 256 characters
    // int counter = 0;
    // printf("Enter text. Use enter to exit\n");
    // do
    // {
    // text[counter]=getchar();
    // counter++;
    // }
    // while ((text[counter] != ' \n ' )&&(counter<3));
    // printf("%s\n",text);
    // return 0;
    
   
    
    readConfigFile("./configFile.txt");
    // printf("%c",str_split("ben dover", 'n'));


  

    return 0;
}






